python 999dice.py
u="y"
sleep 3
bash start.sh